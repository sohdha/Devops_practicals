<!DOCTYPE html>
<html>
<head>
    <title>My Wiki</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <header>
        <h1>My Wiki</h1>
        <nav>
            <a href="#">Home</a>
            <a href="#">Articles</a>
            <a href="#">Categories</a>
        </nav>
    </header>
    <main>
        <h2>Welcome to My Wiki</h2>
        <p>This is devops practical 4</p>
    </main>
    <footer>
        <p>&copy; 2023 My Wiki</p>
    </footer>
</body>
</html>
